# -*- coding: utf-8 -*-
import xbmcaddon
import xbmcgui

addon       = xbmcaddon.Addon()
addonname   = addon.getAddonInfo('Name')
 
line1 = "נא לעדכן את המערכת לגרסה 2.0.5"
line2 = "יש עדכונים בשרת לגרסה חדשה יותר"
line3 = "הוראות התקנה:גשו לאריח-מערכת-מרכז העדכונים-בחרו גרסה מתאימה"

messagetext     ='http://dkrepo.netai.net/UltimateUfc/info.xml'+'?%d=%s' % (random.randint(1, 10000), random.randint(1, 10000))
                                                               
def GetMenu():
        popup()
        link=open_url(baseurl)
        match= re.compile('<item>(.+?)</item>').findall(link)
        for item in match:
                data=re.compile('<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>').findall(item)
                for name,url,iconimage,fanart in data:
                        addDir(name,url,1,iconimage,fanart)
        addDir('[B][COLOR white]Search[/COLOR][/B] [B][COLOR red]UFC Finest[/COLOR][/B]',url,5,searchicon,fanarts)
        xbmc.executebuiltin('Container.SetViewMode(500)')


def popup():
        message=open_url2(messagetext)
        if len(message)>1:
                path = xbmcaddon.Addon().getAddonInfo('path')
                comparefile = os.path.join(os.path.join(path,''), 'compare.txt')
                r = open(comparefile)
                compfile = r.read()       
                if compfile == message:pass
                else:
                        showText('[B][COLOR red]התראות עדכונים[/COLOR] [COLOR white]התראה חדשה לעדכון מערכת[/COLOR][/B]', message)
                        text_file = open(comparefile, "w")
                        text_file.write(message)
                        text_file.close()
                      

xbmcgui.Dialog().ok(addonname, line1, line2, line3)
