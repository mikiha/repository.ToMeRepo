from comtypes.gen import _C866CA3A_32F7_11D2_9602_00C04F8EE628_0_5_4
globals().update(_C866CA3A_32F7_11D2_9602_00C04F8EE628_0_5_4.__dict__)
__name__ = 'comtypes.gen.SpeechLib'