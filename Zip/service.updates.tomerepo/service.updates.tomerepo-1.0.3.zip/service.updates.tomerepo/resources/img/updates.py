# -*- coding: utf-8 -*-
import os, urllib, xbmc, zipfile, xbmcgui

dialog = xbmcgui.Dialog()

def ExtractAll(_in, _out):
	try:
		zin = zipfile.ZipFile(_in, 'r')
		zin.extractall(_out)
	except Exception, e:
		print str(e)
		return False

	return True

	
	
def updatetomer():
		
	url = "https://github.com/tmkodirepo/Update-ToMeR-Wizard/blob/master/photos-Icon-7.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isra.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass	

	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos") 
	
        dialog.ok('עדכון שמספרו 2.0.5','העדכון הותקן בהצלחה','המערכת מעודכנת לגרסה אחרונה','ToMeR Wizard')	