# -*- coding: utf-8 -*-

##########################################################################
#Thanks to TheWiz                                                        #
# Thanks to Blazetamer, Eleazar Coding, Showgun, TheHighway, ....        #
##########################################################################


import shutil, sys, os, xbmcgui, time, xbmc, urllib, urllib2, re, zipfile ,xbmcaddon
import updates
dialog       =  xbmcgui.Dialog()
Progress = xbmcgui.DialogProgress()

#כל עדכון לשנות מספר  
#הקובץ נוצר בתיקית addon data
tomerupdate = '2.1.4.txt'

def fona():
    choice = xbmcgui.Dialog().yesno('[COLOR=Orange]ToMeR Wizard עדכון גרסה[/COLOR]', 'המערכת מצאה עדכון חדש שמספרו 2.0.5', 'האם לעדכן?', nolabel='לא',yeslabel='כן')
    if choice == 0:
        sys.exit(1)
    elif choice == 1:
        pass

def CheckRun(addonID):
	target = xbmc.translatePath(os.path.join('special://userdata','addon_data',addonID)); 
	DoneFile = os.path.join(target,tomerupdate)
	SettingFile = os.path.join(target,'settings.xml')
	if not os.path.isfile(SettingFile):
		Addon.openSettings()
	if not os.path.isfile(DoneFile):
		while True:
			if os.path.isfile(SettingFile):
				return 1
			xbmc.sleep(4000)
	else:
		return 0



global repo_addons, AddonName
addonID = "service.updates.tomerepo"
Addon = xbmcaddon.Addon(addonID)
AddonName = Addon.getAddonInfo("name")
localizedString = Addon.getLocalizedString 
repo_addons = {}

time.sleep(5)

if not CheckRun(addonID):
	sys.exit(1)





addon_data = xbmc.translatePath(os.path.join('special://userdata','addon_data',addonID)); 
DoneFile = os.path.join(addon_data,tomerupdate)
f = open(DoneFile, 'w');f.write(".");f.close();



fona()		
		
#if Addon.getSetting("Update") == "true":
Progress.create("מוריד עדכונים", "נא להמתין...")
Progress.update(50)
updates.updatetomer()
Progress.update(100)
	








sys.exit(1)