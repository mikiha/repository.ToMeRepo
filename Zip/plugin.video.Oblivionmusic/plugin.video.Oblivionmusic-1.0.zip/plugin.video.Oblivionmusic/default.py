# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Music sourced from yoube
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# Author: Oblivion
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.Oblivionmusic'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_CHANNEL_ID_1 = "PLc6SbbuuWtLmCc0C4hHEL2KapV81W7Rbx"  #Now That's What I Call Summer Party
YOUTUBE_CHANNEL_ID_2 = "PL_IGfDhmSGBMtrZrP0X440vgv5iBRfhy4"   #Now That's What I Call Music! 86
YOUTUBE_CHANNEL_ID_3 = "PL_34_m4eTlaNQBMQYxfxQLN7eUkIKP66y"   #Now That's What I Call Pop
YOUTUBE_CHANNEL_ID_4 = "PLE57E7E0C9FF37E2F"                   #NOW...That's What I Call Music(1998 - 2002)
YOUTUBE_CHANNEL_ID_5 = "PLp_5APVRQcDDd4BomBt2-7jJapPedXpx8"   #NOW That's What I Call Music! 90
YOUTUBE_CHANNEL_ID_6 = "PL_34_m4eTlaMf-42RHro2x2UVMHNEkLvD"   #NOW That's What I Call Music! 91
YOUTUBE_CHANNEL_ID_7 = "PL_34_m4eTlaOFcXryY7OFbYGtK5Y1JoIa"   #NOW That's What I Call Music! 92
YOUTUBE_CHANNEL_ID_8 = "PL_34_m4eTlaN5Dj1kIzrJMX95HRBLqeQr"   #NOW That's What I Call Music! 93
YOUTUBE_CHANNEL_ID_9 = "PL69m2raz7e19GuYPGRQE2C_9AVrELyDHN"   #NOW That's What I Call Reggae
YOUTUBE_CHANNEL_ID_10 = "PLL55rJswZPUY6pNadCpeBlZaivnbA42PM"  #80s Playlist
YOUTUBE_CHANNEL_ID_11 = "PL61F36662FCE211B1"                  #90s Playlist
YOUTUBE_CHANNEL_ID_12 = "PLpuDUpB0osJmZQ0a3n6imXirSu0QAZIqF"  #2000's Playlist
YOUTUBE_CHANNEL_ID_13 = "PL55713C70BA91BD6E"                  #Billboard Top Songs 2016
YOUTUBE_CHANNEL_ID_14 = "PLy_wKxVmWb4YTLt2Y1uZ2cX7CQZYEY9r1"  #Reggae Top Tracks
YOUTUBE_CHANNEL_ID_15 = "PL910DBC8BB06CF834"                  #Clubland Classix
YOUTUBE_CHANNEL_ID_16 = "PLQog_FHUHAFVRsO4otlwzn0bZspSAefOl"  #Top Tracks – Soul Music
YOUTUBE_CHANNEL_ID_17 = "PLz8JsiLUtVnA76pgXdnX_70eyko7t3dU_"  #MTV 2016
YOUTUBE_CHANNEL_ID_18 = "PLB4BA618535AB00BF"                  #SKA Early Reggae
YOUTUBE_CHANNEL_ID_19 = "PLcM4ZwI542CpvxGYARIo66SU4917w7y7F"  #SKA 1980s
YOUTUBE_CHANNEL_ID_20 = "PLQJGTgKSnIm1t_fwqFEaqFZHEYuAYB8EF"  #UB40
YOUTUBE_CHANNEL_ID_21 = "PL127ED826E4C4A180"                  #Bob Marley
YOUTUBE_CHANNEL_ID_22 = "PL8B3018E27F2455A6"                  #Bob Marley & The Wailers
YOUTUBE_CHANNEL_ID_23 = "PL8EC5F5F8B35525F6"                  #The Who
YOUTUBE_CHANNEL_ID_24 = "PL178BBE03C02F3C51"                  #The Specials
YOUTUBE_CHANNEL_ID_25 = "PL449BB2C50DD94AC5"                  #Beastie Boys
YOUTUBE_CHANNEL_ID_26 = "PL04D238461FC13025"                  #Bad Manners
YOUTUBE_CHANNEL_ID_27 = "PLWjlJ2HPVR-2GD6nG-9EbtHHAEBgXEm6O"  #Madonna
YOUTUBE_CHANNEL_ID_28 = "PLv0xxnsafXYzRwnDYJ35u0NzC2aeGqCZZ"  #Olly Murs
YOUTUBE_CHANNEL_ID_29 = "PLKjg8qXwrWtRbiAiBGM1WA98EMwRotUFl"  #The Vamps
YOUTUBE_CHANNEL_ID_30 = "PLP93qczU2CNC-Z7IfNakiTPbjN6ODL-pk"  #Little Mix
YOUTUBE_CHANNEL_ID_31 = "PLi7ihgkEws7Tc-nS8VRpFvJPMmwx8KNbF"  #Adele
YOUTUBE_CHANNEL_ID_32 = "PL8F57FD5DC8209241"                  #Rihanna
YOUTUBE_CHANNEL_ID_33 = "PL1B51BDFDD5DD43A6"                  #Taylor Swift
YOUTUBE_CHANNEL_ID_34 = "PL1D0BAE87AB78F03B"                  #Meat Loaf
YOUTUBE_CHANNEL_ID_35 = "PLYONaaT-hcURLV3P7glJz7DRpJahYQ9pY"  #Flo Rider
YOUTUBE_CHANNEL_ID_36 = "PLIhLN7Z5xAvEURXboGP6niaIzlcw-o9Dd"  #Katy Perry
YOUTUBE_CHANNEL_ID_37 = "PL9309F6E6083B49D5"                  #Simon & Garfunkel
YOUTUBE_CHANNEL_ID_38 = "PL6608AC92D1A7DFEC"                  #Pink Floyd
YOUTUBE_CHANNEL_ID_39 = "PLE4918BAF9638BDE7"                  #Ellie Goulding
YOUTUBE_CHANNEL_ID_40 = "PLWifY4ZVngjfsRWcaplbD2m1muE3b5Wn-"  #Coldplay - Greatest Hits
YOUTUBE_CHANNEL_ID_41 = "PLFCE02B6276FA7BAB"                  #Mariah Carey
YOUTUBE_CHANNEL_ID_42 = "PLLT4d5g-0sz9JBIuU0tKnSBkRa_IcZb0w"  #Prince
YOUTUBE_CHANNEL_ID_43 = "PL184EB4A9FA67F0A2"                  #Beyonce's
YOUTUBE_CHANNEL_ID_44 = "PLLyW3WXHbmPrhivrynd1W1Ip962alpL8B"  #Bryson Tiller
YOUTUBE_CHANNEL_ID_45 = "PLJ7wAJLf8gsm-QUUKZVx3ztoP9KDRvBT4"  #Chris Brown
YOUTUBE_CHANNEL_ID_46 = "PLCD6FCCF7FB681357"                  #David Bowie
YOUTUBE_CHANNEL_ID_47 = "PL01BBB94919734C85"                  #Demi Lovato
YOUTUBE_CHANNEL_ID_48 = "PLG21NIjJC_HUFxOsHKGueNoPyv-v9Ywap"  #Elle king
YOUTUBE_CHANNEL_ID_49 = "PLz7sN3C1IENZgiksjWxlJQLWuoOyZGQeq"  #Ed Sheeran
YOUTUBE_CHANNEL_ID_50 = "PL5AF2BB5BEBCD49E9"                  #Ed Eminem

# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

                                                                     
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]NOW That's What I Call Summer Party[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="https://static-s.aa-cdn.net/img/ios/495255309/0ef002852dd7ad9e12d224e48f5ac4bc?v=1",
        folder=True )
                                                                        
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]NOW That's What I Call Music! 86[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_2+"/",
        thumbnail="https://static-s.aa-cdn.net/img/ios/495255309/0ef002852dd7ad9e12d224e48f5ac4bc?v=1",
        folder=True )
                                                                                
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]NOW That's What I Call Pop[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_3+"/",
        thumbnail="https://static-s.aa-cdn.net/img/ios/495255309/0ef002852dd7ad9e12d224e48f5ac4bc?v=1",
        folder=True )
                                                                                      
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]NOW That's What I Call Music(1998 - 2002)[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_4+"/",
        thumbnail="https://static-s.aa-cdn.net/img/ios/495255309/0ef002852dd7ad9e12d224e48f5ac4bc?v=1",
        folder=True )
                                                                                             
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]NOW That's What I Call Music! 90[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_5+"/",
        thumbnail="http://www.cdworld.ie/images/product/n/now-thats-what-i-call-music-90-256px-256px.jpg",
        folder=True )
                                                                                                 
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]NOW That's What I Call Music! 91[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_6+"/",
        thumbnail="http://www.cdworld.ie/images/product/n/now-thats-what-i-call-music-91-256px-256px.jpg",
        folder=True )                                                  
                                                                                                     
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]NOW That's What I Call Music! 92[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_7+"/",
        thumbnail="https://static-s.aa-cdn.net/img/ios/495255309/0ef002852dd7ad9e12d224e48f5ac4bc?v=1",
        folder=True )
                                                                                                             
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]NOW That's What I Call Music! 93[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_8+"/",
        thumbnail="https://static-s.aa-cdn.net/img/ios/495255309/0ef002852dd7ad9e12d224e48f5ac4bc?v=1",
        folder=True )
                                                                                                                     
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]NOW That's What I Call Reggae[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_9+"/",
        thumbnail="https://static-s.aa-cdn.net/img/ios/495255309/0ef002852dd7ad9e12d224e48f5ac4bc?v=1",
        folder=True )
                                                                                                                                                                                                             
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]80s Playlist[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_10+"/",
        thumbnail="https://superrepo.org/static/images/icons/original/plugin.video.thegreat80s.png.pagespeed.ce.IIkY6fPjka.png",
        folder=True )
                                                                                                                                                                                           
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]90s Playlist[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_11+"/",
        thumbnail="https://pbs.twimg.com/profile_images/707609308901453824/HkKqW-0e.jpg",
        folder=True )
                                                                                                                                                                                                   
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]2000's Playlist[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_12+"/",
        thumbnail="http://rymimg.com/lk/f/s/64be561ecdd1d76c7e0532369a6fa9be/3647952.jpg",
        folder=True ) 
      
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]Billboard Top Songs 2016[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_13+"/",
        thumbnail="https://static-s.aa-cdn.net/img/ios/477974718/9a72d9bdf1408099e6223341d6e5c59a?v=1",
        folder=True )  
      
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]Reggae Top Tracks[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_14+"/",
        thumbnail="https://static-s.aa-cdn.net/img/ios/400003487/53d786c6611d7c0865cbdb16e1336d17",
        folder=True )
         
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]Clubland Classix[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_15+"/",
        thumbnail="https://i.ytimg.com/vi/s-Y7z9EyxaE/hqdefault.jpg?custom=true&w=120&h=90&jpg444=true&jpgq=90&sp=68&sigh=T9SrhbriF4e-Wy2W7gCehd59WL4",
        folder=True ) 
                
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]Top Tracks – Soul Music[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_16+"/",
        thumbnail="http://1.bp.blogspot.com/-LCPjCDQGmns/UMxHjTZ__mI/AAAAAAAAAn0/eYOKZ_oOSgA/s1600/top.png",
        folder=True )
           
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]MTV 2016[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_17+"/",
        thumbnail="https://superrepo.org/static/images/icons/original/xplugin.video.mdmtvuk.png.pagespeed.ic.c6kyF5yyrm.png",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]SKA Early Reggae[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_18+"/",
        thumbnail="http://static.wixstatic.com/media/b50b4c20a9df024bc677ff3580235b48.wix_mp_256",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]British Ska Classics 1980s[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_19+"/",
        thumbnail="https://zenius-i-vanisher.com/pictures/4888-1451413849.png",
        folder=True )          
    
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]UB40[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_20+"/",
        thumbnail="https://images-na.ssl-images-amazon.com/images/I/518lVNKzwDL._SL256_.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]Bob Marley[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_21+"/",
        thumbnail="https://manjaribhatnagar.files.wordpress.com/2013/02/bob-marley.jpg?w=256&h=256&crop=1",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]Bob Marley & The Wailers[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_22+"/",
        thumbnail="http://store.ugsounds.com/images/product/b/bob-marley-and-the-wailers-marley-the-original-soundtrack-cd-256px-256px.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]The Who[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_23+"/",
        thumbnail="https://pbs.twimg.com/profile_images/621217999907880961/w9Ic4xyM.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]The Specials[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_24+"/",
        thumbnail="http://www.starzik.com/covers/albums/Specials-Special-Edition-2562045615.jpg",
        folder=True )                

    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]Beastie Boys[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_25+"/",
        thumbnail="http://c-sf.smule.com/s26/arr/3f/64/8b9ddbba-bc6c-4437-bc6f-9607a071968c.jpg",
        folder=True )  

    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]Bad Manners[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_26+"/",
        thumbnail="http://www.starzik.com/covers/albums/Legends-Bad-Manners-2562070098.jpg",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]Madonna[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_27+"/",
        thumbnail="https://images-na.ssl-images-amazon.com/images/I/515kt2x5dDL._SL256_.jpg",
        folder=True ) 
        
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]Olly Murs[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_28+"/",
        thumbnail="http://ichef.bbci.co.uk/images/ic/256x256/p01br4cx.jpg",
        folder=True ) 
            
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]The Vamps[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_29+"/",
        thumbnail="http://is1.mzstatic.com/image/thumb/Music3/v4/b1/5b/26/b15b2656-80f5-3ea8-f50e-84079a22becd/source/256x256bb.jpg",
        folder=True ) 
        
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]Little Mix[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_30+"/",
        thumbnail="http://ichef.bbci.co.uk/images/ic/256x256/p02rw30k.jpg",
        folder=True )
                
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]Adele[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_31+"/",
        thumbnail="http://ichef.bbci.co.uk/images/ic/256x256/p03604sg.jpg",
        folder=True )
                        
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]Rihanna[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_32+"/",
        thumbnail="https://pbs.twimg.com/profile_images/712172839932067840/vk2nARR2.jpg",
        folder=True )
                                
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]Taylor Swift[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_33+"/",
        thumbnail="https://pbs.twimg.com/profile_images/645297505081671680/KZ5beV65.png",
        folder=True )
                                        
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]Meat Loaf[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_34+"/",
        thumbnail="http://www.starzik.com/covers/albums/Piece-of-the-Action-The-Best-of-Meat-Loaf-256366387.jpg",
        folder=True )
                                                
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]Flo Rider[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_35+"/",
        thumbnail="http://ichef.bbci.co.uk/images/ic/256x256/p01bqwcn.jpg",
        folder=True )
                                                        
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]Katy Perry[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_36+"/",
        thumbnail="http://images.latinpost.com/data/images/full/3309/katy-perry.jpeg",
        folder=True )
                                                                                                  
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]Simon & Garfunkel[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_37+"/",
        thumbnail="http://store.ugsounds.com/images/product/s/simon-and-garfunkel-the-complete-album-collection-lp-256px-256px.jpg",
        folder=True )
                                                                                                                                     
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]Pink Floyd[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_38+"/",
        thumbnail="http://ichef.bbci.co.uk/images/ic/256x256/p02d4m02.jpg",
        folder=True )
                                                                                                                                              
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]Ellie Goulding[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_39+"/",
        thumbnail="http://ichef.bbci.co.uk/images/ic/256x256/p0335pfl.jpg",
        folder=True ) 
                                                                                                                                                      
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]Coldplay - Greatest Hits[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_40+"/",
        thumbnail="http://www.vosspain.net/sites/default/files/coldplay.jpg",
        folder=True )
                                                                                                                                                                 
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]Mariah Carey[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_41+"/",
        thumbnail="http://www.twoop.com/wp-content/uploads/2015/01/Mariah-Carey-Butterfly.png",
        folder=True )
                                                                                                                                                                         
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]Prince[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_42+"/",
        thumbnail="http://static.wixstatic.com/media/202acc_1839b570f5ca474c858d2fbc3928445d.jpg_256",
        folder=True )
                                                                                                                                                                                    
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]Beyonce[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_43+"/",
        thumbnail="http://2.bp.blogspot.com/-c8qGm9HBveE/UEbLqcxoIzI/AAAAAAAAALE/uRNBeuZueEU/s1600/beyonce__193.gif",
        folder=True )
        
                                                                                                                                                                                          
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]Bryson Tiller[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_44+"/",
        thumbnail="http://c-sf.smule.com/s30/arr/a7/40/a9d8a368-38f2-490b-a21d-24b25bc8f5c2.jpg",
        folder=True )  
                                                                                                                                                                                          
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]Chris Brown[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_45+"/",
        thumbnail="http://ichef.bbci.co.uk/images/ic/256x256/p037z1bt.jpg",
        folder=True )
                                                                                                                                                                                              
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]David Bowie[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_46+"/",
        thumbnail="http://is4.mzstatic.com/image/thumb/Music6/v4/e3/e5/22/e3e522f1-7b50-dc6b-d263-60f35d5e14f7/source/256x256bb.jpg",
        folder=True )
                                                                                                                                                                                                  
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]Demi Lovato[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_47+"/",
        thumbnail="https://pbs.twimg.com/profile_images/726632681925013504/oUtekY2c.jpg",
        folder=True )
                                                                                                                                                                                                     
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]Elle king[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_48+"/",
        thumbnail="http://ichef.bbci.co.uk/images/ic/256x256/p03r2fqh.jpg",
        folder=True )
                                                                                                                                                                                                         
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]Ed Sheeran[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_49+"/",
        thumbnail="http://c-sf.smule.com/s21/arr/9f/22/eb8636ad-b1f9-4e51-b3d8-8f19d129f02c.jpg",
        folder=True )
                                                                                                                                                                                                            
    plugintools.add_item( 
        #action="", 
        title="[COLORgold][B]Eminem[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_50+"/",
        thumbnail="http://c-sf.smule.com/s23/arr/6c/7e/b50905f3-85da-46fb-8b79-15b0ee24cb55.jpg",
        folder=True )                               
                                                              

run()
