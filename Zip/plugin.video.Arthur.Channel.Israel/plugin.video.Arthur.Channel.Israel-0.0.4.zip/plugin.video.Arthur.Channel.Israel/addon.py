﻿import os
import xbmc

def playIt():	
	playlist = xbmc.PlayList( xbmc.PLAYLIST_VIDEO )
	playlist.clear()
	playlist.add('plugin://plugin.video.youtube/play/?playlist_id=PLEZkO5Ag-uQrvRmTIzFaU8NGQvEguteos&order=shuffle')
	xbmc.Player().play(playlist)
	
try:
	playIt()

except Exception, e:
	playIt()
	exit(1)