# -*- coding: utf-8 -*-

########ToMeR For Addons Premium##########


import urllib,urllib2,re,xbmcplugin,xbmcgui,os,sys,datetime
from resources.lib.common_variables import *
from resources.lib.directory import *
from resources.lib.youtubewrapper import *
from resources.lib.watched import * 

fanart = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.nostalgia', 'fanart.jpg'))
art = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.nostalgia/resources/img', ''))

def CATEGORIES():
        addDir('חינוכית-תוכניות עבר','url',11,art + '70.jpg')
        addDir('חינוכית-ילדים נוסטלגיה','url',12,art + '71.jpg')
        addDir('חינוכית-ילדים','url',20,art + '287.jpg')
        addDir('חינוכית-תוכניות משודרות','url',14,art + '72.jpg')
        addDir('חינוכית-לומדים מהבית','url',17,art + '75.jpg')
        addDir('חינוכית-מוזיקה','url',19,art + '288.jpg')
        addDir('חינוכית-ספיישלים','url',18,art + '279.jpg')
		
		
def nostalgia():	
		addDir('בילבי - הסרט המלא מדובב'+translate(30059)+'','PLiRWC7Q54Gipy0AKSfNBs3cy5j5PL0ODz',1,art + '306.jpg')	
		addDir('לאן יהודים לאן'+translate(30059)+'','PL45D145EEFF323EF1',1,art + '271.jpg')	
		addDir('עברית בסימנטוב'+translate(30057)+'','PL51YAgTlfPj7z_fK_Sklm-S0MADQVS-Zh',1,art + '256.jpg')
		addDir('פגישה עם סופר'+translate(30021)+'','PL51YAgTlfPj6c9WpeMqBRHuMMLdARsOIl',1,art + '218.jpg')
		addDir('מה פתאום'+translate(30021)+'','PL51YAgTlfPj6Y8TPlvSP29SBEK2YzX6UC',1,art + '215.jpg')
		addDir('דנידינה'+translate(30021)+'','PL2ZWSou1jCkgRRhmqqRmz_jIiSCoxnOhI',1,art + '6.jpg')
		addDir('שרתי לך ארצי'+translate(30021)+'','PLLttfoK87AdUxzLIyhq070W9fe8uSQT9h',1,art + '154.jpg')
		addDir('גם אנו שופטים'+translate(30022)+'','PL2ZWSou1jCkgO2tjJ_b6f54jNfh5yxA1w',1,art + '7.jpg')
		addDir('אנחנו'+translate(30023)+'','PL2ZWSou1jCkg65bHddf6_uUgMRVQuQqom',1,art + '8.jpg')
		addDir('אין בעיה עם דודו טופז'+translate(30023)+'','PL51YAgTlfPj4tQNSa0P2f18xxVyA-G11x',1,art + '207.jpg')
		addDir('ריץ רץ'+translate(30059)+'','PLiRWC7Q54GiqmyQh7kTpMROF8mVSGFa5Q',1,art + '159.jpg')
		addDir('דבי בבית חולים'+translate(30059)+'','PL51YAgTlfPj7XhtXmAGGejgA8d8xk2m11&index=3',1,art + '160.jpg')
		addDir('ניקוי ראש'+translate(30021)+'','PLLttfoK87AdWkaAQTs1ddlhdhooBk26Bh',1,art + '155.jpg')
		addDir('זהו זה'+translate(30024)+'','PL2ZWSou1jCkgIqzXRF10XgRtASFhT6Fzr',1,art + '9.jpg')
		addDir('זהו זה - מערכונים קצרים','PL51YAgTlfPj6YNFu1RaXRrKl4wYAB1YZ1',1,art + '9.jpg')
		addDir('ציפיטפוט'+translate(30025)+'','PL2ZWSou1jCki_l6pMqE3vm2yR4cqWbJql',1,art + '10.jpg')
		addDir('הדוברמן החברמן'+translate(30026)+'','PL2ZWSou1jCkhoiIsQ5ulJpCrERP5YhaCh',1,art + '11.jpg')
		addDir('שעת כושר'+translate(30027)+'','PL2ZWSou1jCkj0xW8htgeJfvoaVSSFQjaR',1,art + '12.jpg')
		addDir('האיים אבודים'+translate(30021)+'','PLRpSOtNcr-nFtxYRjAbXMYbZuTUetlhQA',1,art + '151.jpg')
		addDir('עוד סיפור'+translate(30028)+'','PL2ZWSou1jCkiQuXZHFU3PWXgC4J6eYiKM',1,art + '13.jpg')
		addDir('ציפי בלי הפסקה'+translate(30029)+'','PLozcTjklgUYyG9WCyBJ5tM7wXjSNZZ-4Z',1,art + '206.jpg')
		addDir('בתיה עוזיאל'+translate(30030)+'','PL2ZWSou1jCkjpRRbW0Zg6dNiZns-o4H2J',1,art + '15.jpg')
		addDir('מה זאת אומרת'+translate(30031)+'','PL2ZWSou1jCkgOkSv-pa40tjYGssr80YFu',1,art + '16.jpg')
		addDir('השעה שלנו'+translate(30032)+'','PL2ZWSou1jCkj-zlc79D6PAbtJ1c83_8Tz',1,art + '17.jpg')
		addDir('שניים אוחזין'+translate(30034)+'','PL2ZWSou1jCkjCG6X8Aojp_aQYLisBccE6',1,art + '19.jpg')
		addDir('שובו של השריף'+translate(30035)+'','PL2ZWSou1jCkhp6_5CNAQLg1QT6YCdPA64',1,art + '20.jpg')
		addDir('משדרי הביולוגיה הראשונים'+translate(30036)+'','PL2ZWSou1jCkhp6_5CNAQLg1QT6YCdPA64',1,art + '21.jpg')
		addDir('מושגי יסוד ביהדות'+translate(30037)+'','PL2ZWSou1jCkjalPrmfZC9WbAisTau4uez',1,art + '22.jpg')
		addDir('יוצא מן הכלל'+translate(30038)+'','PL2ZWSou1jCkg-ni4Rf2VElyCYlNXbkCAJ',1,art + '23.jpg')
		addDir('דלת הקסמים'+translate(30039)+'','PL2ZWSou1jCkjj231haFQyE787KZce7I-T',1,art + '24.jpg')
		addDir('דן ועדנה'+translate(30040)+'','PL2ZWSou1jCkgBMfVqgq_yX98dEd39BGIs',1,art + '25.jpg')
		addDir('הרפתקאות תום סוייר - הסרט המלא והמקורי כולל תרגום'+translate(30059)+'','PLiRWC7Q54GioYrl2TBDomEZUZ1c1CJTN8',1,art + '296.jpg')
		addDir('בולבול הקבולבול'+translate(30041)+'','PL2ZWSou1jCkj2medujsVWr6DiBQrEvQHz',1,art + '26.jpg')
		addDir('רואים 6/6'+translate(30042)+'','PL2ZWSou1jCkii5mQfIWt8BaEl8PwF41z9',1,art + '27.jpg')
		addDir('קרובים קרובים'+translate(30043)+'','PL2ZWSou1jCkgAney3rJgsJa0V4yhYbUDG',1,art + '28.jpg')
		addDir('פיצוחים'+translate(30044)+'','PL2ZWSou1jCkjPV9ILga3udm6D27M0VXtI',1,art + '29.jpg')
		addDir('סולו'+translate(30045)+'','PL2ZWSou1jCkjMzXLDwfW2fB6Dm35N_fGz',1,art + '30.jpg')
		addDir('מסך לספרות'+translate(30046)+'','PL2ZWSou1jCkiC1s6pEIlWjK0B72WrMUNn',1,art + '31.jpg')
		addDir('חשבון פשוט'+translate(30047)+'','PL2ZWSou1jCkj0GMbiBn0u_dCJRIhttNTT',1,art + '32.jpg')
		addDir('השריף מגבעות הוליווד'+translate(30048)+'','PL2ZWSou1jCkjXLj9ZTCsUY3ET0sJXr0YN',1,art + '33.jpg')
		addDir('Police file'+translate(30050)+'','PL2ZWSou1jCkhjLsA5QY3VstqDI6RakBkP',1,art + '35.jpg')
		addDir('Mission: Possible'+translate(30051)+'','PL2ZWSou1jCkh6APhNV4AUmzzd_kY53ctS',1,art + '37.jpg')
		addDir('ארץ מולדת'+translate(30052)+'','PL2ZWSou1jCkjYnhH2VTX6nE6LzYFxHnKs',1,art + '38.jpg')
		addDir('Signal CQ Calling'+translate(30054)+'','PL2ZWSou1jCkgi_a2X8IAdmLfrG5_cOAq5',1,art + '40.jpg')
		addDir('Neighbours'+translate(30055)+'','PL2ZWSou1jCkioehq3dj0z9qmZed9Qe7G-',1,art + '41.jpg')
		addDir('Here we are'+translate(30057)+'','PL2ZWSou1jCkiUbjMohokWFVTB2TJZjg7v',1,art + '42.jpg')
		addDir('Radio Fever'+translate(30059)+'','PL6A9E9B129E1AB41C',1,art + '274.jpg')
		addDir('The Prisoner - האסיר'+translate(30059)+'','PLAPGcD5LGrp46MmLZPQ45Au-KGlVCS-8h',1,art + '294.jpg')
		addDir('השריף מגבעות הוליווד'+translate(30059)+'','PL2ZWSou1jCkjXLj9ZTCsUY3ET0sJXr0YN',1,art + '44.jpg')
		addDir('אוטוטו'+translate(30060)+'','PLiRWC7Q54GiqzldwN6JhsSijHVjl47bTm',1,art + '45.jpg')
		addDir('הילדים משכונת חיים'+translate(30063)+'','PLth1a195qHsheaBGI4s9qdNasYvbvrZWn',1,art + '48.jpg')
		addDir('בבית של פיסטוק'+translate(30064)+'','PLiRWC7Q54Giqfs7fOeL6Jy4CzYDvwmU_y',1,art + '49.jpg')
		addDir('קריאת כיוון'+translate(30064)+'','PLth1a195qHsg9WremkaI-ImiRcK93HloW',1,art + '64.jpg')
		addDir('קשת וענן'+translate(30064)+'','PL51YAgTlfPj6qcpdP7e44dNj7xHuwd3oo',1,art + '65.jpg')	
		addDir('בלי סודות'+translate(30064)+'','PLth1a195qHsjudbGdTH0hYZ6yk2ZuILXb',1,art + '67.jpg')
		addDir('עניין של זמן - העונה הראשונה'+translate(30059)+'','PLiRWC7Q54GipZ7KO8jtKlLzIQM3klZ49t',1,art + '91.jpg')
		addDir('עניין של זמן - העונה השנייה'+translate(30059)+'','PLiRWC7Q54Gio7XZ2RK6g2FGEr5XfFRmyb',1,art + '92.jpg')		
		addDir('עניין של זמן - העונה השלישית'+translate(30059)+'','PLiRWC7Q54GirpuU4HEqyegkNY2xGJt8E4',1,art + '93.jpg')		
		addDir('עניין של זמן - העונה הרביעית'+translate(30059)+'','PLiRWC7Q54Giq-GD5WK0otino7jjBNZyvo',1,art + '94.jpg')
		addDir('עשרים פלוס - כל העונות'+translate(30059)+'','PL51YAgTlfPj7hNn37mL60Dkhck-md70nR',1,art + '106.jpg')
		addDir('שמש - עונה ראשונה'+translate(30059)+'','PLOPG7FmwtX9AaioGmCuKtHIavFIFJyL1e',1,art + '144.jpg')		
		addDir('שמש - עונה שנייה'+translate(30059)+'','PLOPG7FmwtX9BlrccG151xuuZcPbGmm-KZ',1,art + '144.jpg')	
		addDir('שמש - עונה שלישית'+translate(30059)+'','PLOPG7FmwtX9DqdLxKVyzgcsqV2kOm4rnR',1,art + '144.jpg')	
		addDir('שמש - עונה רביעית'+translate(30059)+'','PLOPG7FmwtX9AhMk3q-yOkyreXNB0amnBS',1,art + '144.jpg')	
		addDir('שמש - עונה חמישית'+translate(30059)+'','PLOPG7FmwtX9A-476AA_m8krkARvjbhOwn',1,art + '144.jpg')	
		addDir('שמש - עונה שישית'+translate(30059)+'','PLOPG7FmwtX9D6yBQqUzQVNw7AFSeeQ3d4',1,art + '144.jpg')	
		addDir('חצי המנשה'+translate(30059)+'','PLrrGhNe9FN6vie1pyq13mudHgDo9lgQuc',1,art + '145.jpg')	
		addDir('פאפא עם זאב רווח'+translate(30059)+'','PLiRWC7Q54GirG6MucE7FKdbOpnfuB509L',1,art + '148.jpg')
		addDir('זינזאנה - עונה ראשונה'+translate(30059)+'','PLqpQbUV9_KNckweh7vVCijKcNDMVrOzXS',1,art + '149.jpg')
		addDir('זינזאנה - עונה שנייה - לא פעיל זמנית'+translate(30059)+'','PLDc3XXHuge25iuzv0rRgWq8a2YZM_wm5o',1,art + '149.jpg')
		addDir('זינזאנה - עונה שלישית - לא פעיל זמנית'+translate(30059)+'','PLDc3XXHuge25uaKqgb7GUnXP2_q01sRX8',1,art + '149.jpg')
		addDir('החברה הטובים - עונה ראשונה'+translate(30059)+'','PLiRWC7Q54GipHFWqu8BKivIBQKMNlPA1i',1,art + '150.jpg')
		addDir('החברה הטובים - עונה שנייה'+translate(30059)+'','PLiRWC7Q54GiqinSFTx1A7pXWjH21U5pt_',1,art + '150.jpg')
		addDir('החברה הטובים - עונה שלישית'+translate(30059)+'','PLiRWC7Q54GirQyGL__8R3_ao8b0Ong4sq',1,art + '150.jpg')
		addDir('אסכולה'+translate(30059)+'','PL51YAgTlfPj4NUt_gtD2AA6tD5zWXmO3g',1,art + '173.jpg')	
		addDir('שבעים פנים'+translate(30059)+'','PL51YAgTlfPj4_euQ9QLSONWvFbmGjoSJc&index=9',1,art + '174.jpg')	
		addDir('קשר משפחתי'+translate(30059)+'','PL51YAgTlfPj4qMe3mNyJ8W38Y157LLPjh',1,art + '177.jpg')
		addDir('מי בחלילית'+translate(30059)+'','PL51YAgTlfPj58DIAef8lhaUVAirMrZFdz',1,art + '178.jpg')
		addDir('אופרה אחרת'+translate(30059)+'','PL51YAgTlfPj6m5hbuhGYPLxFBsN-qD-Mj&index=4',1,art + '179.jpg')
		addDir('זהירות ציפי בדרכים'+translate(30059)+'','PL51YAgTlfPj4ZsfObFMOLKpQP22c9Qizt',1,art + '212.jpg')
		addDir('אכפת לי'+translate(30059)+'','PL51YAgTlfPj40wYDFVEnd7-PxuLDmfGd6',1,art + '225.jpg')
		addDir('ארצנו הקטנטונת'+translate(30059)+'','PL51YAgTlfPj5pd5gBisAd4eV9h266ari2',1,art + '254.jpg')
		addDir('סופי לעת עתה'+translate(30059)+'','PLB7C7C77FF944FF70&index=2',1,art + '273.jpg')
		addDir('משפחה וחצי'+translate(30059)+'','PLiRWC7Q54GiobmVn_n3DKlOsgyV7zS_uI',1,art + '289.jpg')
		addDir('ספי - ספי ריבלין - עונה ראשונה'+translate(30059)+'','PLiRWC7Q54GiqnzdaxmjL7rJbqNsYYiFPC',1,art + '317.jpg')
		addDir('מוצ"ש - ספי ריבליו'+translate(30059)+'','PLiRWC7Q54Giq86kHcJGInrW7WgEKWjt29',1,art + '318.jpg')
		addDir('לא כולל שירות'+translate(30059)+'','PLLttfoK87AdXQM9BaWjichoLYzHSMftJ4',1,art + '319.jpg')
		addDir('רמת אביב גימל'+translate(30059)+'','PLqpQbUV9_KNegBVtccbmjS36OLF_MBrzf',1,art + '290.jpg')
		addDir('בסימן ונוס - עם יהודה לוי'+translate(30059)+'','PLiRWC7Q54Giqn3TWjAzhy25TlkGUJC1H4',1,art + '291.jpg')
		addDir('הוא והיא'+translate(30059)+'','PLqpQbUV9_KNc4KH15ec-tMWV11UVIhgCU',1,art + '293.jpg')
		addDir('החיים זה לא הכל - עונות 1-9'+translate(30059)+'','PLF-gmNgJY5aOm5-0JJC5LKJpWFqRUzFU1',1,art + '307.jpg')
		addDir('קצרים - עונה ראשונה'+translate(30059)+'','PLCWuG3cXW_gbLwdWkEkrVwiVlY295JN52',1,art + '308.jpg')
		addDir('קצרים - עונה שניה'+translate(30059)+'','PLCWuG3cXW_gYcoxRcrc9PoipZ7epAoWfi',1,art + '308.jpg')
		addDir('קצרים - עונה שלישית'+translate(30059)+'','PLeGYz9828YeCjtxY3AqaJxIpHGhpck4AR',1,art + '308.jpg')
		addDir('מעושרות - עונה ראשונה'+translate(30059)+'','PLkOqf0e1GsUfEPSaRNaNi0fkksW6JApto',1,art + '312.jpg')
		addDir('מעושרות עונה שנייה'+translate(30059)+'','PLkOqf0e1GsUdO0H1MUA0BZ6w2PUET-YB2',1,art + '312.jpg')
		addDir('מעושרות - עונה שלישית'+translate(30059)+'','PLkOqf0e1GsUf_x4c1dlm6KBbOw-Hbwgq6',1,art + '312.jpg')
		addDir('הרווק עם דודו אהרון'+translate(30059)+'','PLkOqf0e1GsUfvAwAE5vR3TAZ8aiEH02hH',1,art + '313.jpg')
		addDir('נשות הטייסים'+translate(30059)+'','PLkOqf0e1GsUcfzK0c6vBubi3hwvEeBdEe',1,art + '314.jpg')
		addDir('להתבגר'+translate(30059)+'','PLkOqf0e1GsUfPEgBfKQzthv_-rGn8UiOA',1,art + '315.jpg')

		
def kids():
		addDir('ארתור - עונה ראשונה'+translate(30059)+'','PL-NIkmWdkQcJJe1RKjovNkMeEu648jbnI',1,art + '2.jpg')
		addDir('ארתור - עונה שנייה'+translate(30059)+'','PLJ9grwuaPAHpABj-ikIM6-FAEaYWY-TJL&index=42',1,art + '2.jpg')
		addDir('ארתור סרטים מלאים - מדובב'+translate(30059)+'','PLiRWC7Q54GiqkFzigXHiWLu7XuZ8RzF2c',1,art + '2.jpg')
		addDir('רחוב סומסום'+translate(30059)+'','PLiRWC7Q54GirvSRr5qCQpek5I7d-2E9wy',1,art + '3.jpg')
		addDir('פרפר נחמד'+translate(30059)+'','PLiRWC7Q54Giqlg5hlFuxwNlMgBqZy6qlX',1,art + '4.jpg')
		addDir('פרפר נחמד - פרקים חדשים'+translate(30059)+'','PL51YAgTlfPj48eZZD9HC7x-y8qFYP9cc3',1,art + '66.jpg')
		addDir('פרפר נחמד - מיטב השירים'+translate(30059)+'','PL51YAgTlfPj45OPEXI-ibfJy8ON0k1ARh',1,art + '229.jpg')
		addDir('רגע עם דודלי'+translate(30059)+'','PLiRWC7Q54Girpq3KvHR6aG622I08I84vm',1,art + '5.jpg')
		addDir('מועדון החתול שמיל'+translate(30059)+'','PLiRWC7Q54GipEz1Em790vHMgb0nRsz1bi',1,art + '320.jpg')
		addDir('בסוד העניינים'+translate(30062)+'','PLth1a195qHsg7gc7YWrBIlxU3Q0HtlN1W',1,art + '47.jpg')
		addDir('גברת פלפלת'+translate(30062)+'','PLiRWC7Q54Girgh5eEpe4CVJ0xAbaJI4dv',1,art + '50.jpg')	
		addDir('נילס הולגרסון'+translate(30062)+'','PLiRWC7Q54GiqW9drljsiFfaEIcFoF2DOf',1,art + '51.jpg')			
		addDir('הלב-מרקו'+translate(30062)+'','PLwXEsK85wc0OGtVFt-5kEiQN6s3Qlu62a',1,art + '52.jpg')	
		addDir('עליסה בארץ הפלאות'+translate(30062)+'','PLwXEsK85wc0MhPZOPkLqi4dsACdBg3hE8',1,art + '53.jpg')		
		addDir('היה היה (האדם)'+translate(30062)+'','PL_8KXLhQVQMIyhlZ3d0_5WBTkOlBtsycD',1,art + '54.jpg')		
		addDir('היה היה (החיים)'+translate(30062)+'','PL_8KXLhQVQMKwhT305Cq6x2CrOe8RTNg9',1,art + '55.jpg')
		addDir('חוש חש הבלש'+translate(30059)+'','PL_8KXLhQVQMI9gO_WHO3tMYT5LykW0SMP',1,art + '304.jpg')		
		addDir('דן הדוור'+translate(30062)+'','PL_8KXLhQVQMK05YV3wTQ4SZyEo2kWDvNH',1,art + '305.jpg')	
		addDir('אגדות אחים גרים - עונה ראשונה'+translate(30059)+'','PLqpQbUV9_KNen5kh_3A2jxPmI6O_fmGpj',1,art + '292.jpg')
		addDir('אגדות אחים גרים - עונה שנייה'+translate(30059)+'','PLYlrzbISBfktPBUHxCckXbRxD6KkCapzu',1,art + '292.jpg')
		addDir('טוב טוב הגמד'+translate(30059)+'','PLiRWC7Q54Giq9r_9Ap4TFcCi4Kt0ev97L',1,art + '298.jpg')
		addDir('דני שובבני'+translate(30059)+'','PLiRWC7Q54GiqqIncfiV3x9ZliDGX65jqA',1,art + '295.jpg')
		addDir('דין דין השופט'+translate(30059)+'','PLiRWC7Q54GiqBr8Lg24bxGLdzHAQchCXz',1,art + '299.jpg')
		addDir('הקוסם מארץ עוץ'+translate(30059)+'','PLiRWC7Q54GirgmEacorxJa_DJhfLpKEA1',1,art + '303.jpg')
		addDir('סנדוקאן'+translate(30059)+'','PLiRWC7Q54GirRdxg6UeP0s01s105WmHge',1,art + '300.jpg')	
		addDir('שאלתיאל קוואק - עונה ראשונה'+translate(30062)+'','PL_8KXLhQVQMKOtRoV1SuOu95dvVo-ea2J',1,art + '57.jpg')	
		addDir('שאלתיאל קוואק - עונה שנייה'+translate(30062)+'','PLZIgNCxEpVtGDv8g4o6E9BSGlT4ekMi12',1,art + '57.jpg')	
		addDir('המעופפים הנועזים'+translate(30062)+'','PL_8KXLhQVQMLhguXwe-d2HjvficZsfbEj',1,art + '58.jpg')		
		addDir('שלגייה ושבעת הגמדים'+translate(30062)+'','PL_8KXLhQVQMKKrMMm0glr1TMQoxCjFuTk',1,art + '59.jpg')	
		addDir('המומינים'+translate(30062)+'','PL_8KXLhQVQMLvEJlwakyjEeFfOgGQKaCo',1,art + '60.jpg')
		addDir('המומינים הסרט המלא - מדובב'+translate(30062)+'','PLiRWC7Q54GirwTcpxVcE0rk1aRASH97Wt',1,art + '60.jpg')		
		addDir('פינוקיו'+translate(30062)+'','PLwXEsK85wc0OQV1DgaY4zC0_CiB8ZD5j9',1,art + '61.jpg')		
		addDir('טאו-טאו'+translate(30062)+'','PLwXEsK85wc0OMTKgRKShDXO73wEv4B-c9',1,art + '62.jpg')			
		addDir('הדרדסים'+translate(30062)+'','PLig2mjpwQBZkgIgp6HwDRJjRkRNdnFV-l',1,art + '63.jpg')			
		addDir('קופיקו - עונה ראשונה'+translate(30059)+'','PLR7DTcU2p0QhDzYbbniDNwSbXUM_p6N3f',1,art + '136.jpg')
		addDir('קופיקו - עונה שנייה'+translate(30059)+'','PLR7DTcU2p0QgEdLPHhrhKtxElvYVrseAQ',1,art + '137.jpg')
		addDir('קופיקו - עונה שלישית'+translate(30059)+'','PLMq11W2eqQKQ2bcTcccLG_simyR0SXZP-',1,art + '138.jpg')
		addDir('קופיקו - עונה רביעית'+translate(30059)+'','PLchPUqk2BZjE4b0MbRBYhctCWZn-YtI8B',1,art + '139.jpg')
		addDir('בארץ הקטקטים'+translate(30059)+'','PLRcELC88TCC1EsMVcLidohH_3I9VmUqvX&index=17',1,art + '140.jpg')
		addDir('החתולים הסמוראיים'+translate(30059)+'','PLR7DTcU2p0QhPmznEmitRHkv5RcUG3E-s',1,art + '141.jpg')		
		addDir('בולי איש השלג'+translate(30059)+'','PLiRWC7Q54Gip5kGOgoyCfQefdluYQHNXU',1,art + '142.jpg')
		addDir('המחסן של כאילו'+translate(30059)+'','PLiRWC7Q54GipwVn59JmbETmDIK6Ql2aAM',1,art + '143.jpg')
		addDir('פיטר פן'+translate(30059)+'','PLiRWC7Q54GiqP_RbfqcTFrHlkWgheLp9p',1,art + '309.jpg')
		addDir('שוטרים וגנבים'+translate(30059)+'','PLiRWC7Q54GirvSADJB3xQ1ZahtY6CuKCP',1,art + '146.jpg')	
		addDir('הסיפורים : מיץ פטל, דירה להשכיר והכינה נחמה'+translate(30059)+'','PLiRWC7Q54Giqoj-4lLAsNrJbF_FJLQCPX',1,art + '311.jpg')
		addDir('קוסמים קטנים'+translate(30059)+'','PLiRWC7Q54GipQWO9JCV8jw5Oh537ppA4L',1,art + '147.jpg')	
		addDir('היי בינבה'+translate(30059)+'','PLqpQbUV9_KNdYo_aKLOpN1nGDKsv2dPvz',1,art + '158.jpg')	
		addDir('אוטובוס הקסמים - כל הפרקים'+translate(30059)+'','PLiRWC7Q54Giro76TjZnUnrojgXbPqUG6M',1,art + '297.jpg')		
		addDir('הופה היי'+translate(30059)+'','PLiRWC7Q54Giqp7xe6q_a6bXf6I6ANfrKI',1,art + '322.jpg')	
		addDir('פופאי הסרט המלא - מדובב'+translate(30059)+'','PLiRWC7Q54GipPyZCVkEKUPOalVlLSMZZL&index=2',1,art + '156.jpg')	
		addDir('פופאי-כל הפרקים - 1933-1957'+translate(30059)+'','PLYNF3Io7fWPho8EMa4DQoSZTwWOS9pdRT',1,art + '157.jpg')
	
def Broadcast():		
		addDir('23 דקות'+translate(30064)+'','PL51YAgTlfPj7QDpAtcFy1_-Zf-OUgBFQ1',1,art + '76.jpg')
		addDir('אחלה יום'+translate(30064)+'','PL8AE904EF143BA340',1,art + '278.jpg')
		addDir('אוכל למחשבה'+translate(30064)+'','PLiRWC7Q54Gio3eCzoFAsGLz83HT40QUCZ',1,art + '77.jpg')
		addDir('אומרים שהיה פה'+translate(30064)+'','PL51YAgTlfPj7BNSE3BoiW-hALYC_dATQn',1,art + '78.jpg')		
		addDir('אם לא עכשיו'+translate(30064)+'','PL51YAgTlfPj4TtM4X_skUjtbZPNn8Xttj',1,art + '79.jpg')		
		addDir('ארוחות שעשו היסטוריה'+translate(30064)+'','PL51YAgTlfPj5eW1B7rkqAoU1GmfFHFwWv',1,art + '82.jpg')	
		addDir('הידעת?'+translate(30064)+'','PL51YAgTlfPj6L43UJSC2LfBcxxZYx4Wj4',1,art + '95.jpg')	
		addDir('הבימה מערכה שניה'+translate(30064)+'','PL51YAgTlfPj5R3jFtctL01mBjcjO17hvJ',1,art + '253.jpg')	
		addDir('העפרון הכי מחודד'+translate(30064)+'','PL51YAgTlfPj7tzWxrWGNdyK-gbs1d8qf8',1,art + '96.jpg')	
		addDir('ואקום - עונה ראשונה'+translate(30064)+'','PL51YAgTlfPj6ij1PPVnvJG9mliQNrDT_h',1,art + '97.jpg')	
		addDir('ואקום - עונה שנייה'+translate(30064)+'','PL51YAgTlfPj4EcYSIWN-zM8vmmFktDXF5',1,art + '98.jpg')	
		addDir('חדר 101'+translate(30064)+'','PL51YAgTlfPj4aV-7HTNop6JovkBRT6B7x',1,art + '99.jpg')	
		addDir('חוצה ישראל - עם קובי מידן'+translate(30064)+'','PL127E7734AE7476DD',1,art + '100.jpg')	
		addDir('חותם אישי'+translate(30064)+'','PL51YAgTlfPj5klM0RPo1k7J5iDS6otYG8',1,art + '101.jpg')	
		addDir('חיות במה'+translate(30064)+'','PL51YAgTlfPj7iPkOqCZpCQNtf7W6kqQ6x',1,art + '103.jpg')	
		addDir('חלם בהלם'+translate(30064)+'','PL51YAgTlfPj63PcR3r2VmhG95qmPzXouc',1,art + '105.jpg')	
		addDir('כאן ואומן'+translate(30064)+'','PL51YAgTlfPj4WTj-7ffYUJpt2FDvS5ivo',1,art + '107.jpg')
		addDir('כנסת נכבדה'+translate(30064)+'','PL51YAgTlfPj4wTsnXOgf0OBcoaiO7kQfg',1,art + '108.jpg')		
		addDir('להיות מדען עם פרופסור דן'+translate(30064)+'','PL51YAgTlfPj4oR5aIC0Ru5JZA1a1TT-RN',1,art + '109.jpg')	
		addDir('מה זה מוזה - עונה ראשונה'+translate(30064)+'','PL51YAgTlfPj4F8EkY07BfV1KhdjmtjX0P',1,art + '111.jpg')	
		addDir('מה זה מוזה - עונה שנייה'+translate(30064)+'','PLth1a195qHsj20lXv4QqTQ7kb2RLoGxY8',1,art + '112.jpg')		
		addDir('עולם הבובות של גלי'+translate(30064)+'','PL51YAgTlfPj5y9-iDpGCcw1Rf1YhMl85m',1,art + '113.jpg')				
		addDir('פסקול ישראלי שירים בודדים'+translate(30064)+'','PLQlJ8z_GdC2mFwtiO4ZT2zEISrmnd8yOh',1,art + '115.jpg')		
		addDir('שטרודל'+translate(30064)+'','PL51YAgTlfPj5Hw7X0PY-mLgVYFFm0TK5b',1,art + '117.jpg')
		addDir('אדריכלות ישראלית'+translate(30064)+'','PL51YAgTlfPj6Ajq6brj2sbLQ0AEmD10L_&index=9',1,art + '252.jpg')
		addDir('שיחת נפש'+translate(30064)+'','PL51YAgTlfPj4hWCdqRdSppJk2akOip3Q4',1,art + '118.jpg')
		addDir('תיק תקשורת'+translate(30064)+'','PL7vmWmvl4quhFxAvjy6rlACnTKhtcpSyk',1,art + '119.jpg')
		addDir('חדש בעיניים'+translate(30064)+'','PL51YAgTlfPj5qPsqwLPkxs_-lkIJZfg0H',1,art + '161.jpg')
		addDir('המושכים בחוטים'+translate(30064)+'','PL51YAgTlfPj6s0QtcgOpIwKewkEeSN77e',1,art + '163.jpg')		
		addDir('הכל פתוח'+translate(30064)+'','PL51YAgTlfPj4LovalcoZLy7TPJ8oAL0k6',1,art + '164.jpg')		
		addDir('הכל אנשים'+translate(30064)+'','PL51YAgTlfPj7TAvhkV8c9UnnMHUpQy-Bx',1,art + '165.jpg')
		addDir('חדשות מהעבר - עונה ראשונה'+translate(30064)+'','PL51YAgTlfPj76Eh3jZ6V5lRvuAp6lHU1e',1,art + '166.jpg')
		addDir('חדשות מהעבר - עונה שנייה'+translate(30064)+'','PL51YAgTlfPj4IjHf-ISoprm2r9FO0szaD',1,art + '166.jpg')			
		addDir('חדשות מהעבר - עונה שלישית'+translate(30064)+'','PL51YAgTlfPj6Y7AkPBqhGRsHNaG77e2f9',1,art + '166.jpg')	
		addDir('היו סרטים'+translate(30064)+'','PL51YAgTlfPj474gCGLEUa7_Zo5Bxgy9fG&index=43',1,art + '167.jpg')
		addDir('טעמים'+translate(30064)+'','PL51YAgTlfPj6FX0sryFAHDSQPB5fb0Ye9',1,art + '168.jpg')
		addDir('זה מזה'+translate(30059)+'','PL51YAgTlfPj6JtH-ZS7brPS6CS2R02nmw',1,art + '171.jpg')
		addDir('בין השורות'+translate(30059)+'','PL51YAgTlfPj6fMz_DxFpb-wgQDgR6YAOf',1,art + '196.jpg')		
		addDir('גאון של אבא'+translate(30059)+'','PL51YAgTlfPj65xupugNnupcCT0tzS_HH3',1,art + '172.jpg')	
		addDir('פלאשבק'+translate(30059)+'','PL51YAgTlfPj6gEP4qa6lTQy3P8jcRMS3z',1,art + '180.jpg')
		addDir('מה הסיפור? - עונה ראשונה'+translate(30059)+'','PL51YAgTlfPj4pXBYq0rXfkLDWdNriJ_3-',1,art + '181.jpg')
		addDir('מה הסיפור? - עונה שנייה'+translate(30059)+'','PL51YAgTlfPj5cz5fWddeMmXQ_97bNjBh-&index=3',1,art + '181.jpg')		
		addDir('שערוריה'+translate(30059)+'','PL51YAgTlfPj4S_9xEMNDAw9N6HLPD8tfi',1,art + '182.jpg')		
		addDir('מוסף המוספים'+translate(30059)+'','PL51YAgTlfPj6RCZ4v_lgajIiOU3PM6nNo',1,art + '185.jpg')
		addDir('הקשר הישראלי - עונה שנייה'+translate(30059)+'','PL51YAgTlfPj6H-qyug15LKMTvLY9TgwVN',1,art + '190.jpg')
		addDir('זמן הורים'+translate(30059)+'','PL51YAgTlfPj4njfaDOYLtyRfowZaDbPZE',1,art + '199.jpg')
		addDir('אינטרמצו עם אריק - עונה ראשונה'+translate(30059)+'','PL51YAgTlfPj5K-DyuhP5FghHHN8x0BEgA',1,art + '208.jpg')
		addDir('אינטרמצו עם אריק - עונה שנייה'+translate(30059)+'','PL51YAgTlfPj7pQXCOUwNohLCvkbusvqD6',1,art + '208.jpg')
		addDir('פרופיל 2013'+translate(30059)+'','PL51YAgTlfPj5zbilu3Z8azxJpv24X1dwn',1,art + '211.jpg')
		addDir('לינק+'+translate(30059)+'','PL51YAgTlfPj4D7japJmmP4L0urxx3j33R',1,art + '213.jpg')
		addDir('הכל תרבות'+translate(30059)+'','PL51YAgTlfPj4wnHAqF1cabFNSv3p9RCfr&index=2',1,art + '216.jpg')
		addDir('חי בסרט'+translate(30059)+'','PL51YAgTlfPj4ph_DTmh2pYW-ENXxsNXVb',1,art + '221.jpg')	
		addDir('גדולים מהחיים-הדור הבא'+translate(30059)+'','PL51YAgTlfPj7BJiKn76rVDpDvMP4bGd55',1,art + '223.jpg')
		addDir('שם נולדתי'+translate(30059)+'','PL51YAgTlfPj5ghNY2qA41CzTan9WPf01m',1,art + '224.jpg')		
		addDir('עניין של טעם - בישול מהספרים'+translate(30059)+'','PL51YAgTlfPj56FLWmFEiqFjNIHjKJlO3j',1,art + '249.jpg')	
		addDir('עניין של טעם'+translate(30059)+'','PL51YAgTlfPj4nexv1mWGSmQB2fmwuAwUw',1,art + '249.jpg')
		addDir('2,3 הקשב'+translate(30059)+'','PL51YAgTlfPj74EndXG78h2Oqw60Mk8yWx',1,art + '250.jpg')
		addDir('ההפסקה הגדולה'+translate(30059)+'','PLFF36DACC75CDB042',1,art + '251.jpg')
		addDir('זרקור עם גל גבאי'+translate(30059)+'','PL51YAgTlfPj6bjzN59BD70vmYuXlURzEo',1,art + '255.jpg')
		addDir('סברס'+translate(30059)+'','PL51YAgTlfPj72fEPM2Mu76jTrHOg8SEok',1,art + '257.jpg')	
		addDir('לשון המראות'+translate(30059)+'','PL3D2F6C62B695FE89',1,art + '261.jpg')
		addDir('שיחות ברוח'+translate(30059)+'','PLABDA0375B943DAEC',1,art + '263.jpg')
		addDir('ברית עם מילה'+translate(30059)+'','PLBA7E16EB421A5F60',1,art + '264.jpg')
		addDir('המושבעים'+translate(30059)+'','PLAB74682339E0173C',1,art + '265.jpg')
		addDir('אני לא כזה'+translate(30059)+'','PL8AF214FE9865E579',1,art + '267.jpg')	
		addDir('כן לציפור'+translate(30059)+'','PL41D53039B90917B0',1,art + '268.jpg')

		
def lomdim():		
		addDir('דן ועדנה - לימוד אנגלית'+translate(30059)+'','PL51YAgTlfPj781aLgQXZNeCcbn9qXbX5E',1,art + '104.jpg')
		addDir('הלו פנינה - לימוד עברית'+translate(30064)+'','PL8Ydu6CcDpZQoXCvRq_O7l0AcgaV1aiV6',1,art + '120.jpg')
		addDir('תעלם ותכלם - לימוד ערבית'+translate(30033)+'','PL2ZWSou1jCkichu7tlmSIk6FmmFEJ3i64',1,art + '18.jpg')
		addDir('Candy Can Do It - לימוד אנגלית'+translate(30064)+'','PL8Ydu6CcDpZSJQmln2O90W_3EMBsuqXOE',1,art + '121.jpg')
		addDir('IN ITALIANO - לימוד איטלקית'+translate(30064)+'','PL8Ydu6CcDpZSuA5DcAszNLFpQ-QdnZXHF',1,art + '122.jpg')
		addDir('גבי ודבי - לימוד אנגלית'+translate(30056)+'','PL2ZWSou1jCkhfZ4rEHTR0OIXh1GyIqDPw',1,art + '36.jpg')
		addDir('Dites Moi Tout - לימוד צרפתית'+translate(30064)+'','PL8Ydu6CcDpZRzt1ZB6WZFWdbIg-MDUv3l',1,art + '123.jpg')
		addDir('בוא נתערב - לימוד עברית'+translate(30064)+'','PL8Ydu6CcDpZRqp5xJ5YpXUZWspJa6YE_8',1,art + '124.jpg')
		addDir('English English English - לימוד אנגלית'+translate(30058)+'','PL2ZWSou1jCkgZ0AhwJe5D3j2-QmNovBRq',1,art + '43.jpg')
		addDir('More About English - לימוד אנגלית'+translate(30064)+'','PL8Ydu6CcDpZReqe4i8tPvyzYv3_z5jw_N',1,art + '125.jpg')
		addDir('גלילאו - עונה רביעית'+translate(30064)+'','PL51YAgTlfPj5ERxljvk0cLQAjnLMj3son',1,art + '84.jpg')	
		addDir('גלילאו - עונה חמישית'+translate(30064)+'','PL51YAgTlfPj6Ypxb-_Dh0eoCztCXiBYsN',1,art + '84.jpg')	
		addDir('גלילאו - עונה שישית'+translate(30064)+'','PL51YAgTlfPj5RB1GQe2OoPwFWTcwFMFDs',1,art + '84.jpg')	
		addDir('גלילאו - עונה שביעית'+translate(30064)+'','PL51YAgTlfPj5UDRn7jbyChrKst-WUX_qF',1,art + '84.jpg')	
		addDir('גיאומטריה'+translate(30049)+'','PL2ZWSou1jCkimo8aEXsW0qGT8FDIto0rL',1,art + '34.jpg')
		addDir('נאס"א : העולם שלנו'+translate(30049)+'','PL51YAgTlfPj4fkOhV8lrwQsz8e-JDoynm&index=43',1,art + '189.jpg')
		addDir('אוצרות ומכמנים'+translate(30049)+'','PL51YAgTlfPj6Nb8bGTwxIrCQQG9yzcKuq',1,art + '191.jpg')
		addDir('חידון התנ"ך'+translate(30049)+'','PL51YAgTlfPj51ODBIMhtOF_lYxjS1cuQh',1,art + '192.jpg')
		addDir('ערב חדש לילדים'+translate(30049)+'','PL51YAgTlfPj5_wjkZreM5E7NScaGBFYLe',1,art + '193.jpg')
		addDir('מי בא לקישקשתא?'+translate(30049)+'','PL51YAgTlfPj7McnJ8UQse9KH58JaxZWF4',1,art + '194.jpg')
		addDir('קישקשתא בדרכים - המקום הנכון לחצות'+translate(30049)+'','PL51YAgTlfPj5szmjjHjRrx2OQ4mX4aUev',1,art + '195.jpg')
		addDir('בית ספר לקוסמים'+translate(30049)+'','PL51YAgTlfPj6KxVL84Li-dp6BnOB0gChG',1,art + '197.jpg')
		addDir('תנ"ך בחרוזים'+translate(30049)+'','PL51YAgTlfPj5NmIEX774qPsqFVeWLKptt',1,art + '217.jpg')
		addDir('קרב מוחות'+translate(30049)+'','PL51YAgTlfPj54RN3mRLW566n82cttFOer',1,art + '226.jpg')
		addDir('מנת משכל'+translate(30049)+'','PL51YAgTlfPj4-rWObWycjkZM1M54s3j4D',1,art + '228.jpg')	
		addDir('Signal CQ Calling'+translate(30054)+'','PL2ZWSou1jCkgi_a2X8IAdmLfrG5_cOAq5',1,art + '40.jpg')
		addDir('Neighbours'+translate(30055)+'','PL2ZWSou1jCkioehq3dj0z9qmZed9Qe7G-',1,art + '41.jpg')
		addDir('Here we are'+translate(30057)+'','PL2ZWSou1jCkiUbjMohokWFVTB2TJZjg7v',1,art + '42.jpg')
		addDir('לשם שינוי - בגרות באזרחות'+translate(30057)+'','PLBAF8C2237E80A6DC',1,art + '259.jpg')
		addDir('זה לא עסק'+translate(30059)+'','PLBE9EAFE6BA307506',1,art + '260.jpg')	
		addDir('סובב ישראל'+translate(30059)+'','PLE196ECE55F4B8629',1,art + '270.jpg')	
		addDir('לאן יהודים לאן'+translate(30059)+'','PL45D145EEFF323EF1',1,art + '271.jpg')	
		addDir('כמה כמה'+translate(30059)+'','PLD04AADEEA392DE2F',1,art + '275.jpg')	
		addDir('יוצרים עם חנוך פיבן'+translate(30059)+'','PLCE8D051221B747EC',1,art + '277.jpg')
		addDir('חשבון פשוט-חשבון לכיתה ד'+translate(30059)+'','PL8EFCDA3F0C14856E',1,art + '276.jpg')
		addDir('ספיישל לומדים - כל התוכניות'+translate(30059)+'','PL5966B40FAD38F7D5',1,art + '282.jpg')
		addDir('מורה פרטי - מתמטיקה לבגרות 3 יחידות'+translate(30059)+'','PLD2A326BB34DD9059',1,art + '283.jpg')
		addDir('מורה פרטי - מתמטיקה לבגרות 4 יחידות'+translate(30059)+'','PL4499F9E4F2B0715D',1,art + '283.jpg')
		addDir('מורה פרטי - מתמטיקה לבגרות 5 יחידות'+translate(30059)+'','PL1C7690D248842BE3',1,art + '283.jpg')	

		
def special():		
		addDir('אוצרות נוסטלגיה בשחור לבן'+translate(30059)+'','PL51YAgTlfPj6mH4KRWm7IE_J1geTcVmX9',1,art + '214.jpg')	
		addDir('ארכיון רשות השידור'+translate(30059)+'','PLLttfoK87AdVEUsFtRJCoCXl4Yx0jp-3-&index=4',1,art + '153.jpg')	
		addDir('שידורים לרצח רבין'+translate(30059)+'','PL51YAgTlfPj4QjlggCSzpoZ5VxOFK_CrP',1,art + '162.jpg')
		addDir('חנה מרון 1923-2014'+translate(30059)+'','PL51YAgTlfPj48SyN77XSbSf53_-h7mWp7&index=2',1,art + '198.jpg')
		addDir('ספי ריבלין 1947-2013'+translate(30059)+'','PL51YAgTlfPj7I5Vwy8ZqoY0WpkxnUkabM',1,art + '220.jpg')	
		addDir('אסי דיין 1945-2014'+translate(30059)+'','PL51YAgTlfPj6nOCrX0rG6VXav8pUREFlF',1,art + '202.jpg')	
		addDir('אריק איינשטין 1939-2013 '+translate(30059)+'','PL51YAgTlfPj4LFBKNwCk7Xi1vpkqIkvff',1,art + '222.jpg')
		addDir('אריק איינשטין - שירי ילדים'+translate(30059)+'','PLiRWC7Q54GioRfYpA-0diz-5V3JkR4fOU',1,art + '301.jpg')
		addDir('ספיישל חג חנוכה'+translate(30059)+'','PL51YAgTlfPj6iSrDhUtCLTLeLhq9Bnn3O',1,art + '186.jpg')			
		addDir('ספיישל חג פורים'+translate(30059)+'','PL51YAgTlfPj4KOG8oJrs70F_u8bAVH3lW',1,art + '187.jpg')	
		addDir('ספיישל חג טו בשבט'+translate(30059)+'','PL51YAgTlfPj6Ob3E922l8DoM8U-ay6rwt',1,art + '188.jpg')
		addDir('ספיישל חג פסח'+translate(30059)+'','PL51YAgTlfPj6wyHVgtg0ebuwqYqhh2D_j',1,art + '205.jpg')	
		addDir('חגי תשרי'+translate(30059)+'','PL51YAgTlfPj4LOZbA2VzFPUTkheKOlmaE',1,art + '227.jpg')	
		addDir('תוכניות מיוחדות ליום הזיכרון'+translate(30059)+'','PL51YAgTlfPj4eWriUKWAPnNODq8QR_UlB',1,art + '201.jpg')
		addDir('סיכומי ששת הימים'+translate(30059)+'','PL51YAgTlfPj6h-wbbbnUI-TkwyirGxbcr',1,art + '183.jpg')
		addDir('יום השואה בחינוכית'+translate(30059)+'','PL51YAgTlfPj6zllZWhjkRCv95Q9LPhRZ2',1,art + '184.jpg')	
		addDir('שמיכת טלאים - פרוייקט ליום הזיכרון'+translate(30059)+'','PL51YAgTlfPj40WOr1ylSGNITWbH7r6pAF&index=2',1,art + '203.jpg')	
		addDir('אולפן פתוח-מלחמת המפרץ'+translate(30059)+'','PL51YAgTlfPj406VKwHca6NeZc8RLQe-2U',1,art + '210.jpg')	
		addDir('קולה של אמא'+translate(30059)+'','PL51YAgTlfPj4QX3eKDcyn_GngNv14t6vs',1,art + '258.jpg')	
		addDir('היסטוריה בארץ ישראל'+translate(30059)+'','PL4654A73C7195CDE5',1,art + '279.jpg')	
		addDir('נוסטלגיה באנגלית'+translate(30059)+'','PLD1AA6CFEB351552E',1,art + '281.jpg')		
		addDir('ספורט - משחקים מלאים'+translate(30059)+'','PLAFF0CE2A6D305335',1,art + '280.jpg')		
		addDir('ספיישל תוכניות לילדים'+translate(30059)+'','PLEEADE8D8F08C1CF8',1,art + '284.jpg')	
		addDir('קטעי קאלט נוסטלגיים - חלק א'+translate(30059)+'','PL865DC5C74264BF11',1,art + '285.jpg')	
		addDir('קטעי קאלט נוסטלגיים - חלק ב'+translate(30059)+'','PL78D26C6B20B90459',1,art + '285.jpg')
		addDir('ספיישל אקטואליה ותרבות'+translate(30059)+'','PL41C878044EB8B4DF',1,art + '286.jpg')	
		addDir('אלי יצפאן - DVD CD.3'+translate(30059)+'','PLiRWC7Q54Girm8lG578H1qPG_Pz969MuC',1,art + '302.jpg')	
		addDir('הגשש החיוור - מערכון ראשון'+translate(30059)+'','PLiRWC7Q54Giri9A70bXJVW-tMSo2CGU44',1,art + '316.jpg')
		addDir('הגשש החיוור מערכון שני'+translate(30059)+'','PLiRWC7Q54Gip2koDIPa8PdEcR5VQEXyKU',1,art + '316.jpg')
		addDir('הגשש החיוור - מערכון שלישי'+translate(30059)+'','PLiRWC7Q54Gio5CGviXMVY3YVxbLv_qK6q',1,art + '316.jpg')
		addDir('הגשש החיוור - מערכון רביעי'+translate(30059)+'','PLiRWC7Q54Gip_49naW_JgdMl7ErEg7v1P',1,art + '316.jpg')
		addDir('הגשש החיוור - מערכון חמישי'+translate(30059)+'','PLiRWC7Q54GiriXvtYfEyF3KK19AaehUTt',1,art + '316.jpg')
		addDir('הגשש החיוור - מערכון שישי'+translate(30059)+'','PLiRWC7Q54Gir7R6B-HhTjuCJeKJ3jOagZ',1,art + '316.jpg')	
		addDir('הגשש החיוור - מערכון שביעי'+translate(30059)+'','PLiRWC7Q54Girzfp7JoAGC3EZ32kZIP3Io',1,art + '316.jpg')		
		addDir('הגשש החיוור - מערכון שמיני'+translate(30059)+'','PLiRWC7Q54GiqzKFlRL_hbQ63oCM9Hir3g',1,art + '316.jpg')		
		addDir('הגשש החיוור - מערכון תשיעי'+translate(30059)+'','PLiRWC7Q54Gioi0JiITZtdXf49t0ipt0NO',1,art + '316.jpg')		
		addDir('הגשש החיוור - מערכון עשירי'+translate(30059)+'','PLiRWC7Q54GipBVcMiszAG-azWMfp70N2U',1,art + '316.jpg')	
		
def music():	
		addDir('מחווה לאמן בקאמרי'+translate(30059)+'','PL51YAgTlfPj7m81J5ClB3hjdIZ6CN3uwH',1,art + '176.jpg')
		addDir('מוזיקה היום'+translate(30059)+'','PL51YAgTlfPj4HjSMomAQkLAxTezmoREXn',1,art + '175.jpg')	
		addDir('אני גיטרה - עונה ראשונה'+translate(30064)+'','PL51YAgTlfPj4VO17d-PgLgwhuUMkelg4k',1,art + '80.jpg')	
		addDir('אני גיטרה - עונה שנייה'+translate(30064)+'','PL51YAgTlfPj4SY2HwfowNP3nQ9hKpL2Ko',1,art + '81.jpg')	
		addDir('פסקול ישראלי'+translate(30064)+'','PL51YAgTlfPj4BhoUBgEoRl0LP94e1ivAo',1,art + '114.jpg')
		addDir('חלום לים התיכון'+translate(30064)+'','PL51YAgTlfPj5h_EJBX7YvcKSuclmG2mA6',1,art + '169.jpg')
		addDir('דואט ישראלי'+translate(30064)+'','PL51YAgTlfPj7IzrXIoNEfXzq0BOG-vClM',1,art + '170.jpg')
		addDir('ארכיון רשות השידור - מוזיקה'+translate(30059)+'','PLLttfoK87AdXPHsgVJz0lYhzXrUU_9MxO',1,art + '152.jpg')	
		addDir('כדי שלא יאבד'+translate(30059)+'','PL51YAgTlfPj4dK_dKGEwJY0wG5HYkLLs-',1,art + '200.jpg')
		addDir('זו ילדותי'+translate(30059)+'','PL51YAgTlfPj42DChiYRjfKMHWF5yBKpmJ',1,art + '262.jpg')	
		addDir('מוזיקה ישראלית - קליפים'+translate(30059)+'','PL0CA90DCC0F764E88',1,art + '286.jpg')	
		addDir('פסטיבל שירי ילדים'+translate(30059)+'','PLiRWC7Q54Giryds243PO_ocr2I2cEJb44',1,art + '321.jpg')
		
def kidsnew():
		addDir('בחצר של פופיק - כל העונות'+translate(30064)+'','PLrXHa7yEIVEK4otul2GvgRduQrp_WHozQ',1,art + '83.jpg')	
		addDir('דן ומוזלי - עונה ראשונה'+translate(30064)+'','PLunrwEAfSt0Q4EY9QvJLQ-qcmj26fFGps',1,art + '85.jpg')	
		addDir('דן ומוזלי - עונה שנייה'+translate(30064)+'','PLth1a195qHsh2JB7l8Y-0B8RKTzKeLTzI',1,art + '86.jpg')	
		addDir('דן ומוזלי - עונה שלישית'+translate(30064)+'','PL51YAgTlfPj6HjLShpTpzJfmYbrKtb2iq',1,art + '87.jpg')	
		addDir('כל השירים של דן ומוזלי'+translate(30064)+'','PL51YAgTlfPj6eJ2M_tZhiFUKhh3-xTJ0_',1,art + '102.jpg')	
		addDir('החפרנים - עונה ראשונה'+translate(30064)+'','PL51YAgTlfPj6PWe7kECdyz6ToCjcmSd6z',1,art + '88.jpg')			
		addDir('החפרנים - עונה שנייה'+translate(30064)+'','PLth1a195qHsi9fsrgjDzYTzqKSOF-Ky-N',1,art + '89.jpg')	
		addDir('החפרנים - עונה שלישית'+translate(30064)+'','PL51YAgTlfPj72a-r737sA5zGGmns56uLI',1,art + '90.jpg')	
		addDir('שרגא בישגדא - עונות: 1,2,3,4,5'+translate(30064)+'','PL51YAgTlfPj5KPYOntZkqg2Nwyqj2M1Lf',1,art + '110.jpg')
		addDir('שרגא בישגדא - עונה 6'+translate(30064)+'','PLth1a195qHshVqXbb6tQpRIX9PHQgkjnG',1,art + '110.jpg')
		addDir('שוסטר ושוסטר'+translate(30064)+'','PLth1a195qHshFOAU_eVupbzfvNkhcZ4pq',1,art + '116.jpg')
		addDir('הורים וגורים'+translate(30064)+'','PL51YAgTlfPj5sp5nUKFuwuUddCXYjiH8F',1,art + '209.jpg')
		addDir('תראו אותי'+translate(30064)+'','PL51YAgTlfPj7jf8HAcgMERYrNyHQd6bgD',1,art + '219.jpg')
		addDir('אולפן הבית - מתכונים'+translate(30059)+'','PL51YAgTlfPj6O2gLT7i0Usc5LVRFF-wRT',1,art + '230.jpg')
		addDir('אולפן הבית - שיאים'+translate(30059)+'','PL51YAgTlfPj5LYIrCbBwfFHKVt4C6j8JH',1,art + '231.jpg')
		addDir('אולפן הבית - מילים להחלפה'+translate(30059)+'','PL51YAgTlfPj638OcGN_S_ptSPC-LCcDAv',1,art + '232.jpg')		
		addDir('אולפן הבית - חמשירים'+translate(30059)+'','PL51YAgTlfPj5GovUy3GXS1d2ELtDXyMWt&index=2',1,art + '233.jpg')		
		addDir('אולפן הבית - טריוויה'+translate(30059)+'','PL51YAgTlfPj6mkx1NYiG9fy7fg_lhAM2g',1,art + '234.jpg')
		addDir('אולפן הבית - גן חיות'+translate(30059)+'','PL51YAgTlfPj4-tSuiYCRuXzbG7OVdXkTc',1,art + '235.jpg')		
		addDir('אולפן הבית - סופר בריין'+translate(30059)+'','PL51YAgTlfPj5-7O6pcFU-LDqz38ES7XcX',1,art + '236.jpg')	
		addDir('אולפן הבית - התעוררות'+translate(30059)+'','PL51YAgTlfPj4plw_67m2RCi-YB1yGsQMJ',1,art + '237.jpg')
		addDir('אולפן הבית - פתגם'+translate(30059)+'','PL51YAgTlfPj5fEWuvyYU1Bw5xoksQFCHi',1,art + '238.jpg')
		addDir('אולפן הבית - עצות ומשחקים'+translate(30059)+'','PL51YAgTlfPj4-PoYife4j11pGZzbiqYH3',1,art + '239.jpg')
		addDir('אולפן הבית - ערב'+translate(30059)+'','PL51YAgTlfPj7nXkSHUkn2WR0fDJ8bX8Yc',1,art + '240.jpg')
		addDir('אולפן הבית - היפ הופ'+translate(30059)+'','PL51YAgTlfPj5x1Mpals5RkvP1_SGCLeNO',1,art + '241.jpg')
		addDir('אולפן הבית - דגלים'+translate(30059)+'','PL51YAgTlfPj5wktrVq0M3RDGv4tBdMusP',1,art + '242.jpg')
		addDir('אולפן הבית - מדען'+translate(30059)+'','PL51YAgTlfPj7ramMR-kDnOSbVvkFoswZk',1,art + '243.jpg')
		addDir('בית ספר לשפים מתחילים'+translate(30059)+'','PL51YAgTlfPj7xLodgRH6lTHQysTUKG_Kr',1,art + '244.jpg')
		addDir('המטבחון - בישול לילדים'+translate(30059)+'','PL51YAgTlfPj7mdtecfMQvlvxv2KHI-7BD&index=4',1,art + '245.jpg')
		addDir('הולה הופ - לילדים'+translate(30059)+'','PL51YAgTlfPj4pgezv6SHwl2b9JeHdXnHD',1,art + '246.jpg')
		addDir('יוגה לילדים - סרטוני הדרכה'+translate(30059)+'','PL51YAgTlfPj7wHwsiqOd00V9SBa8XrdNR&index=2',1,art + '247.jpg')
		addDir('רוצים לזוז - כושר ילדים'+translate(30059)+'','PL51YAgTlfPj4-pONO5m1bGZbyuAaxVHK6&index=2',1,art + '204.jpg')
		addDir('פעילויות יצירה לילדים'+translate(30059)+'','PL51YAgTlfPj4gEgcQ7xUnkEMhLJKVqEvE',1,art + '248.jpg')
		addDir('אלימות זה בידיים שלנו'+translate(30059)+'','PL44A6264C94477E4C',1,art + '266.jpg')		
		addDir('בשביל הסיפורים'+translate(30059)+'','PLF1F15FC862BDEB2F',1,art + '269.jpg')	
		addDir('חטף פתח'+translate(30059)+'','PL97498F46F690C8BC',1,art + '272.jpg')	
		addDir('זאק וקוואק'+translate(30059)+'','PL_8KXLhQVQMJM70o-LA7S6ufWVvLCJF9m',1,art + '310.jpg')	

		
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param


params=get_params()
url=None
name=None
mode=None
iconimage=None
page = None
token = None

try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except:
	try: 
		mode=params["mode"]
	except: pass
try: iconimage=urllib.unquote_plus(params["iconimage"])
except: pass
try: token=urllib.unquote_plus(params["token"])
except: pass
try: page=int(params["page"])
except: page = 1

print ("Mode: "+str(mode))
print ("URL: "+str(url))
print ("Name: "+str(name))
print ("iconimage: "+str(iconimage))
print ("Page: "+str(page))
print ("Token: "+str(token))

		
def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="NEXT.png", thumbnailImage=iconimage)
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
		
def addDir3(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setProperty('fanart_image', fanart)
        if mode==35 :
               ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
               return ok
				
def create_directory(dir_path, dir_name=None):
    if dir_name:
        dir_path = os.path.join(dir_path, dir_name)
    dir_path = dir_path.strip()
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)
    return dir_path

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
       
elif mode==1:
        return_youtubevideos(name,url,token,page)

elif mode==5: 
        play_youtube_video(url)

elif mode==6:
        mark_as_watched(url)

elif mode==7:
        removed_watched(url)

elif mode==8:
        add_to_bookmarks(url)

elif mode==9:
        remove_from_bookmarks(url)
		
elif mode==11:
        print ""+url
        nostalgia()

elif mode==12:
        print ""+url
        kids()

elif mode==14:
        print ""+url
        Broadcast()
			
elif mode==17:
        print ""+url
        lomdim()
	
elif mode==18:
        print ""+url
        special()	

elif mode==19:
        print ""+url
        music()

elif mode==20:
        print ""+url
        kidsnew()

		
xbmcplugin.endOfDirectory(int(sys.argv[1]))